
import React from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { motion } from "framer-motion";

export default function Home() {
  return (
    <main className="min-h-screen bg-gradient-to-br from-pink-100 to-purple-100 p-6">
      <motion.div
        className="max-w-4xl mx-auto"
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
      >
        <header className="flex justify-between items-center mb-6">
          <h1 className="text-3xl font-bold text-purple-800">AI-Балапан</h1>
          <div className="space-x-2">
            <Button variant="outline">Қазақша</Button>
            <Button variant="outline">Русский</Button>
          </div>
        </header>

        <section className="text-center mb-8">
          <h2 className="text-xl text-gray-700 mb-2">
            Ұстазға – көмекші құрал, балаға – сапалы тәрбие!
          </h2>
          <Button className="bg-pink-500 text-white">Генерациялау</Button>
        </section>

        <section className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <Card className="rounded-2xl shadow-lg">
            <CardContent className="p-4">
              <h3 className="text-lg font-semibold mb-2">Генерациялау формасы</h3>
              <Input placeholder="Тақырып енгізіңіз" className="mb-2" />
              <Input placeholder="Жас ерекшелік" className="mb-2" />
              <Input placeholder="Мақсат" className="mb-2" />
              <Input placeholder="Тіл таңдаңыз" className="mb-4" />
              <Button className="bg-purple-600 text-white w-full">Генерациялау</Button>
            </CardContent>
          </Card>

          <Card className="rounded-2xl shadow-lg">
            <CardContent className="p-4">
              <h3 className="text-lg font-semibold mb-2">Нәтиже</h3>
              <Textarea placeholder="Генерацияланған мәтін осында шығады..." className="mb-2 h-40" />
              <div className="flex justify-between">
                <Button variant="outline">Көшіру</Button>
                <Button variant="outline">PDF жасау</Button>
              </div>
            </CardContent>
          </Card>
        </section>
      </motion.div>
    </main>
  );
}
